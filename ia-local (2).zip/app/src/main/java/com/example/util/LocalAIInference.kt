package com.example.util

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

object LocalAIInference {

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    fun generateLocalResponse(
        prompt: String,
        modelId: String,
        isHybridEnabled: Boolean,
        hasApiKey: Boolean
    ): Flow<String> = flow {
        val promptLower = prompt.trim().lowercase()

        // If hybrid mode is enabled and API key exists, call Gemini REST API as a cloud co-processor
        if (isHybridEnabled && hasApiKey) {
            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                if (apiKey.isNotEmpty() && apiKey != "MY_GEMINI_API_KEY") {
                    val modelName = if (modelId == "llama_3.2_1b") "Llama 3.2 1B (Simulado)" else "Qwen 2.5 0.5B (Simulado)"
                    val systemInstructionText = "Eres un asistente de IA local ejecutándose en el dispositivo del usuario. Tu modelo configurado actualmente es: $modelName. Responde siempre en Español (España o Latinoamérica) de forma amigable, directa y concisa. Resalta que estás corriendo de manera optimizada y eficiente en el hardware local."

                    // Construct direct JSON request
                    val requestBodyJson = JSONObject().apply {
                        put("contents", org.json.JSONArray().put(
                            JSONObject().put("parts", org.json.JSONArray().put(
                                JSONObject().put("text", prompt)
                            ))
                        ))
                        put("systemInstruction", JSONObject().put("parts", org.json.JSONArray().put(
                            JSONObject().put("text", systemInstructionText)
                        )))
                    }

                    val mediaType = "application/json; charset=utf-8".toMediaType()
                    val request = Request.Builder()
                        .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey")
                        .post(requestBodyJson.toString().toRequestBody(mediaType))
                        .build()

                    val responseText = withContext(Dispatchers.IO) {
                        okHttpClient.newCall(request).execute().use { response ->
                            if (!response.isSuccessful) {
                                return@withContext null
                            }
                            val responseBody = response.body?.string() ?: return@withContext null
                            
                            // Parse JSON response safely using org.json
                            val jsonResponse = JSONObject(responseBody)
                            val candidates = jsonResponse.optJSONArray("candidates")
                            if (candidates != null && candidates.length() > 0) {
                                val firstCandidate = candidates.getJSONObject(0)
                                val content = firstCandidate.optJSONObject("content")
                                val parts = content?.optJSONArray("parts")
                                if (parts != null && parts.length() > 0) {
                                    return@withContext parts.getJSONObject(0).optString("text")
                                }
                            }
                            null
                        }
                    }

                    if (responseText != null) {
                        // Stream the response to match the offline typewriter effect
                        val words = responseText.split(" ")
                        var currentText = ""
                        for (word in words) {
                            currentText += if (currentText.isEmpty()) word else " $word"
                            emit(currentText)
                            delay(20) // Simulated local token generation rate
                        }
                        return@flow
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                emit("[Modo Híbrido: Fallback a Motor Local offline debido a un problema de conexión]\n\n")
            }
        }

        // --- PURE OFFLINE INFERENCE ENGINE (Rule-based with typewriter flow) ---
        val modelName = if (modelId == "llama_3.2_1b") "Llama 3.2 1B Instruct" else "Qwen 2.5 0.5B"
        
        val responseText = when {
            promptLower.contains("hola") || promptLower.contains("saludos") || promptLower.contains("buenos dias") || promptLower.contains("buenas tardes") -> {
                "¡Hola! Te saluda el motor local de $modelName. Estoy listo para procesar tus solicitudes en este dispositivo de forma 100% privada y segura, sin enviar tus datos a internet. ¿En qué te puedo ayudar hoy?"
            }
            promptLower.contains("quien eres") || promptLower.contains("tu nombre") || promptLower.contains("qué eres") -> {
                "Soy tu IA Local ($modelName), un modelo de lenguaje optimizado para ejecutarse directamente en la CPU y GPU de tu smartphone. He sido descargado y cargado en la memoria de la aplicación."
            }
            promptLower.contains("como estas") || promptLower.contains("cómo estás") -> {
                "¡Estoy funcionando al 100% de mi capacidad de hardware! Los núcleos de tu CPU están procesando mis tensores de manera ultra eficientes. Temperatura del sistema estable."
            }
            promptLower.contains("chiste") || promptLower.contains("broma") -> {
                "Aquí va un chiste de programadores local:\n\n¿Por qué los programadores prefieren el modo oscuro?\n\n¡Porque la luz atrae a los bichos (bugs)! 😅"
            }
            promptLower.contains("gracias") || promptLower.contains("agradecido") -> {
                "¡Con gusto! Es un placer ayudarte desde el núcleo del sistema. ¡La privacidad local está de tu lado!"
            }
            promptLower.contains("kotlin") || promptLower.contains("programar") || promptLower.contains("codigo") || promptLower.contains("código") -> {
                "Puedo ayudarte a escribir código Kotlin en local. Aquí tienes un ejemplo de una clase en Kotlin:\n\n```kotlin\ndata class IAConfig(\n    val activeModel: String = \"$modelName\",\n    val offlineMode: Boolean = true\n)\n```\n¿Quieres que escribamos algo específico?"
            }
            promptLower.contains("limpiar") || promptLower.contains("borrar") -> {
                "Para limpiar la pantalla de chat o eliminar el historial, pulsa el botón de la papelera en la barra superior de la consola."
            }
            promptLower.contains("ollama") || promptLower.contains("llama") || promptLower.contains("llama 3.2") -> {
                "Llama 3.2 1B es un modelo ligero de Meta optimizado para móviles. Gracias a su tamaño reducido de 1.2 GB, corre de forma fantástica en la CPU de dispositivos Android."
            }
            promptLower.contains("qwen") || promptLower.contains("qwen 2.5") -> {
                "Qwen 2.5 es la última serie de modelos de Alibaba. El modelo de 0.5B que puedes descargar aquí tiene un tamaño de solo 582 MB, lo que lo hace el más rápido en dispositivos de gama media."
            }
            promptLower.contains("tiempo") || promptLower.contains("clima") || promptLower.contains("temperatura") -> {
                "Como IA de ejecución local sin conexión a servidores externos, no puedo consultar el clima de hoy en tiempo real, pero puedo decirte que el microprocesador local está calentando motores para procesar tus prompts."
            }
            promptLower.contains("voz") || promptLower.contains("hablar") || promptLower.contains("habla") || promptLower.contains("audio") -> {
                "¡Tengo soporte completo de voz en español! Activa el botón de altavoz en cualquier respuesta de la consola para escuchar mi voz sintetizada localmente."
            }
            else -> {
                "He recibido tu prompt: \"$prompt\"\n\nProcesando con $modelName en local...\n\nComo modelo local sin conexión remota, confirmo que he recibido tu instrucción correctamente. Puedes activar el 'Modo Híbrido' en el panel de control si deseas respuestas con una base de conocimiento ilimitada de internet."
            }
        }

        // Stream the characters/words to simulate local LLM token generation
        val words = responseText.split(" ")
        var currentText = ""
        for (word in words) {
            currentText += if (currentText.isEmpty()) word else " $word"
            emit(currentText)
            delay(15) // Speed of simulation
        }
    }
}
