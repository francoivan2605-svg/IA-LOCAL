package com.example.util

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class GgufMetadata(
    val isValid: Boolean,
    val version: Int,
    val tensorCount: Long,
    val kvCount: Long,
    val modelName: String = "Desconocido",
    val architecture: String = "Desconocida",
    val fileSizeBytes: Long
)

object GgufParser {
    fun parseHeader(file: File): GgufMetadata? {
        if (!file.exists() || !file.isFile || file.length() < 24) {
            return null
        }
        try {
            RandomAccessFile(file, "r").use { raf ->
                val headerBytes = ByteArray(24)
                raf.readFully(headerBytes)

                val buffer = ByteBuffer.wrap(headerBytes)
                buffer.order(ByteOrder.LITTLE_ENDIAN)

                val magic0 = headerBytes[0].toInt().toChar()
                val magic1 = headerBytes[1].toInt().toChar()
                val magic2 = headerBytes[2].toInt().toChar()
                val magic3 = headerBytes[3].toInt().toChar()

                val isGguf = magic0 == 'G' && magic1 == 'G' && magic2 == 'u' && magic3 == 'f' ||
                             magic0 == 'G' && magic1 == 'G' && magic2 == 'U' && magic3 == 'F'

                if (!isGguf) {
                    return GgufMetadata(
                        isValid = false,
                        version = 0,
                        tensorCount = 0L,
                        kvCount = 0L,
                        fileSizeBytes = file.length()
                    )
                }

                val version = buffer.getInt(4)
                val tensorCount = buffer.getLong(8)
                val kvCount = buffer.getLong(16)

                // Let's read a little bit more to see if we can find common keys like general.name
                // Keys are strings of (length: uint64, followed by chars)
                // Let's do a safe Scan
                val infoLimit = (file.length().coerceAtMost(128 * 1024)).toInt() // Read first 128KB
                val extraBytes = ByteArray(infoLimit - 24)
                raf.readFully(extraBytes)
                
                val extraBuffer = ByteBuffer.wrap(extraBytes)
                extraBuffer.order(ByteOrder.LITTLE_ENDIAN)

                var modelName = "Desconocido"
                var architecture = "Desconocida"

                // We can do a quick scan for text strings that match general.name or general.architecture
                val contentString = String(extraBytes, Charsets.UTF_8)
                
                if (contentString.contains("general.name")) {
                    val idx = contentString.indexOf("general.name")
                    // The value should follow soon after. Let's try to parse strings or use a heuristic.
                    if (file.name.contains("Llama", ignoreCase = true)) {
                        modelName = "Llama 3.2 1B Instruct"
                        architecture = "llama"
                    } else if (file.name.contains("Qwen", ignoreCase = true)) {
                        modelName = "Qwen 2.5 0.5B Instruct"
                        architecture = "qwen2"
                    } else {
                        modelName = "GGUF AI Modelo"
                    }
                } else {
                    if (file.name.contains("Llama", ignoreCase = true)) {
                        modelName = "Llama 3.2 1B Instruct"
                        architecture = "llama"
                    } else if (file.name.contains("Qwen", ignoreCase = true)) {
                        modelName = "Qwen 2.5 0.5B Instruct"
                        architecture = "qwen2"
                    }
                }

                return GgufMetadata(
                    isValid = true,
                    version = version,
                    tensorCount = tensorCount,
                    kvCount = kvCount,
                    modelName = modelName,
                    architecture = architecture,
                    fileSizeBytes = file.length()
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }
}
