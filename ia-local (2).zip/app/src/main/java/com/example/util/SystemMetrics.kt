package com.example.util

import android.app.ActivityManager
import android.content.Context
import java.io.File

data class SystemInfo(
    val totalStorageGb: Float,
    val freeStorageGb: Float,
    val usedStorageGb: Float,
    val storageUsagePercent: Float,
    val totalRamGb: Float,
    val freeRamGb: Float,
    val usedRamGb: Float,
    val ramUsagePercent: Float,
    val cpuCores: Int
)

object SystemMetrics {
    fun getSystemInfo(context: Context): SystemInfo {
        // Storage Metrics
        val filesDir = context.filesDir
        val totalSpace = filesDir.totalSpace.toFloat() / (1024f * 1024f * 1024f)
        val freeSpace = filesDir.freeSpace.toFloat() / (1024f * 1024f * 1024f)
        val usedSpace = totalSpace - freeSpace
        val storagePercent = if (totalSpace > 0) (usedSpace / totalSpace) * 100f else 0f

        // RAM Metrics
        var totalRam = 0f
        var freeRam = 0f
        var usedRam = 0f
        var ramPercent = 0f
        try {
            val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            if (activityManager != null) {
                val memoryInfo = ActivityManager.MemoryInfo()
                activityManager.getMemoryInfo(memoryInfo)
                totalRam = memoryInfo.totalMem.toFloat() / (1024f * 1024f * 1024f)
                freeRam = memoryInfo.availMem.toFloat() / (1024f * 1024f * 1024f)
                usedRam = totalRam - freeRam
                ramPercent = if (totalRam > 0) (usedRam / totalRam) * 100f else 0f
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // CPU Cores
        val cores = Runtime.getRuntime().availableProcessors()

        return SystemInfo(
            totalStorageGb = String.format("%.2f", totalSpace).replace(",", ".").toFloatOrNull() ?: totalSpace,
            freeStorageGb = String.format("%.2f", freeSpace).replace(",", ".").toFloatOrNull() ?: freeSpace,
            usedStorageGb = String.format("%.2f", usedSpace).replace(",", ".").toFloatOrNull() ?: usedSpace,
            storageUsagePercent = storagePercent,
            totalRamGb = String.format("%.2f", totalRam).replace(",", ".").toFloatOrNull() ?: totalRam,
            freeRamGb = String.format("%.2f", freeRam).replace(",", ".").toFloatOrNull() ?: freeRam,
            usedRamGb = String.format("%.2f", usedRam).replace(",", ".").toFloatOrNull() ?: usedRam,
            ramUsagePercent = ramPercent,
            cpuCores = cores
        )
    }
}
