package com.example.data.repository

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import com.example.data.local.ChatDao
import com.example.data.local.DownloadDao
import com.example.data.model.ChatMessage
import com.example.data.model.DownloadInfo
import com.example.util.GgufMetadata
import com.example.util.GgufParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File

class LocalAIRepository(
    private val context: Context,
    private val downloadDao: DownloadDao,
    private val chatDao: ChatDao
) {
    val allDownloads: Flow<List<DownloadInfo>> = downloadDao.getAllDownloads()
    val allMessages: Flow<List<ChatMessage>> = chatDao.getAllMessages()

    private val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    suspend fun initDefaultDownloads() {
        withContext(Dispatchers.IO) {
            val defaults = listOf(
                DownloadInfo(
                    id = "llama_3.2_1b",
                    name = "Llama 3.2 1B Instruct (GGUF)",
                    downloadUrl = "https://www.dropbox.com/scl/fi/ohva5cbaj5pz9bjpnjflk/Llama-3.2-1B-Instruct-Q8_0.gguf?rlkey=czfcsge18b6nuiss32qwpbrep&st=1gwse4m7&dl=1", // Dropbox dl=1 for direct download
                    localFilePath = File(getStorageDirectory(), "Llama-3.2-1B-Instruct-Q8_0.gguf").absolutePath,
                    status = "NOT_DOWNLOADED",
                    sizeLabel = "1.24 GB"
                ),
                DownloadInfo(
                    id = "qwen_2.5_0.5b",
                    name = "Qwen 2.5 0.5B Instruct (GGUF)",
                    downloadUrl = "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q8_0.gguf",
                    localFilePath = File(getStorageDirectory(), "qwen2.5-0.5b-instruct-q8_0.gguf").absolutePath,
                    status = "NOT_DOWNLOADED",
                    sizeLabel = "582 MB"
                ),
                DownloadInfo(
                    id = "voice_model_es",
                    name = "Modelo de Voz (Español Coqui TTS)",
                    downloadUrl = "https://huggingface.co/k2-fsa/sherpa-onnx-tts-es-coqui-css10/resolve/main/vits-coqui-es-css10.tar.bz2",
                    localFilePath = File(getStorageDirectory(), "vits-coqui-es-css10.tar.bz2").absolutePath,
                    status = "NOT_DOWNLOADED",
                    sizeLabel = "41 MB"
                )
            )

            for (item in defaults) {
                val existing = downloadDao.getDownloadById(item.id)
                if (existing == null) {
                    // Check if file already exists in local storage
                    val file = File(item.localFilePath)
                    val updatedItem = if (file.exists() && file.length() > 10 * 1024 * 1024) {
                        item.copy(status = "COMPLETED", progress = 1.0f, totalBytes = file.length(), downloadedBytes = file.length())
                    } else {
                        item
                    }
                    downloadDao.insertOrUpdate(updatedItem)
                } else {
                    // Check if file is still there
                    val file = File(existing.localFilePath)
                    if (!file.exists() && existing.status == "COMPLETED") {
                        downloadDao.insertOrUpdate(existing.copy(status = "NOT_DOWNLOADED", progress = 0f, downloadedBytes = 0L))
                    } else if (file.exists() && file.length() > 0 && existing.status != "COMPLETED" && existing.status != "DOWNLOADING") {
                        downloadDao.insertOrUpdate(existing.copy(status = "COMPLETED", progress = 1.0f, totalBytes = file.length(), downloadedBytes = file.length()))
                    }
                }
            }
        }
    }

    private fun getStorageDirectory(): File {
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    suspend fun startDownload(id: String) {
        withContext(Dispatchers.IO) {
            val item = downloadDao.getDownloadById(id) ?: return@withContext
            
            // Delete old file if exists
            val oldFile = File(item.localFilePath)
            if (oldFile.exists()) {
                oldFile.delete()
            }

            try {
                // Ensure parent dirs exist
                oldFile.parentFile?.mkdirs()

                // Enqueue DownloadManager request
                val request = DownloadManager.Request(Uri.parse(item.downloadUrl))
                    .setTitle(item.name)
                    .setDescription("Descargando modelo para IA Local")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationUri(Uri.fromFile(oldFile))
                    .setAllowedOverMetered(true)
                    .setAllowedOverRoaming(true)

                val systemDownloadId = downloadManager.enqueue(request)

                downloadDao.insertOrUpdate(
                    item.copy(
                        downloadId = systemDownloadId,
                        status = "DOWNLOADING",
                        progress = 0f,
                        downloadedBytes = 0,
                        totalBytes = 0
                    )
                )
            } catch (e: Exception) {
                e.printStackTrace()
                downloadDao.insertOrUpdate(item.copy(status = "FAILED", progress = 0f))
            }
        }
    }

    suspend fun deleteDownload(id: String) {
        withContext(Dispatchers.IO) {
            val item = downloadDao.getDownloadById(id) ?: return@withContext
            
            // Cancel system download if active
            if (item.downloadId != -1L) {
                try {
                    downloadManager.remove(item.downloadId)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            // Delete file
            val file = File(item.localFilePath)
            if (file.exists()) {
                file.delete()
            }

            downloadDao.insertOrUpdate(
                item.copy(
                    downloadId = -1L,
                    status = "NOT_DOWNLOADED",
                    progress = 0f,
                    downloadedBytes = 0L,
                    totalBytes = 0L
                )
            )
        }
    }

    // Sync active download states with System DownloadManager
    suspend fun syncActiveDownloads() {
        withContext(Dispatchers.IO) {
            val defaults = listOf("llama_3.2_1b", "qwen_2.5_0.5b", "voice_model_es")
            for (id in defaults) {
                val item = downloadDao.getDownloadById(id) ?: continue
                if (item.status == "DOWNLOADING" && item.downloadId != -1L) {
                    val query = DownloadManager.Query().setFilterById(item.downloadId)
                    var cursor = null as android.database.Cursor?
                    try {
                        cursor = downloadManager.query(query)
                        if (cursor != null && cursor.moveToFirst()) {
                            val bytesDownloaded = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                            val bytesTotal = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                            val statusInt = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))

                            var newStatus = "DOWNLOADING"
                            var progress = 0f
                            if (bytesTotal > 0) {
                                progress = bytesDownloaded.toFloat() / bytesTotal.toFloat()
                            }

                            when (statusInt) {
                                DownloadManager.STATUS_SUCCESSFUL -> {
                                    newStatus = "COMPLETED"
                                    progress = 1.0f
                                    // Check if file is really there
                                    val file = File(item.localFilePath)
                                    if (!file.exists()) {
                                        newStatus = "FAILED"
                                        progress = 0f
                                    }
                                }
                                DownloadManager.STATUS_FAILED -> {
                                    newStatus = "FAILED"
                                    progress = 0f
                                }
                                DownloadManager.STATUS_PAUSED -> {
                                    newStatus = "PAUSED"
                                }
                            }

                            downloadDao.updateProgress(
                                downloadId = item.downloadId,
                                progress = progress,
                                downloadedBytes = bytesDownloaded,
                                totalBytes = bytesTotal,
                                status = newStatus
                            )
                        } else {
                            // If cursor is empty, download might have been deleted/cancelled outside
                            // Check if file exists anyway
                            val file = File(item.localFilePath)
                            if (file.exists() && file.length() > 10 * 1024 * 1024) {
                                downloadDao.insertOrUpdate(item.copy(status = "COMPLETED", progress = 1.0f, totalBytes = file.length(), downloadedBytes = file.length()))
                            } else {
                                downloadDao.insertOrUpdate(item.copy(status = "NOT_DOWNLOADED", progress = 0f))
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    } finally {
                        cursor?.close()
                    }
                } else if (item.status != "COMPLETED") {
                    // Double check if file exists anyway (completed while app was dead)
                    val file = File(item.localFilePath)
                    if (file.exists() && file.length() > 10 * 1024 * 1024) {
                        downloadDao.insertOrUpdate(item.copy(status = "COMPLETED", progress = 1.0f, totalBytes = file.length(), downloadedBytes = file.length()))
                    }
                }
            }
        }
    }

    fun parseGgufMetadata(localPath: String): GgufMetadata? {
        val file = File(localPath)
        return GgufParser.parseHeader(file)
    }

    // Chat operations
    suspend fun saveMessage(message: ChatMessage) {
        chatDao.insertMessage(message)
    }

    suspend fun clearChatHistory() {
        chatDao.clearHistory()
    }
}
