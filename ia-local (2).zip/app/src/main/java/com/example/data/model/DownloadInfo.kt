package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "download_info")
data class DownloadInfo(
    @PrimaryKey val id: String,
    val name: String,
    val downloadUrl: String,
    val localFilePath: String,
    val downloadId: Long = -1,
    val progress: Float = 0f,
    val totalBytes: Long = 0,
    val downloadedBytes: Long = 0,
    val status: String = "NOT_DOWNLOADED",
    val sizeLabel: String = ""
)
