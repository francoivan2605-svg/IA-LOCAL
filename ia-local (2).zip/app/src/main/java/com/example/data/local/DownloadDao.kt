package com.example.data.local

import androidx.room.*
import com.example.data.model.DownloadInfo
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {
    @Query("SELECT * FROM download_info")
    fun getAllDownloads(): Flow<List<DownloadInfo>>

    @Query("SELECT * FROM download_info WHERE id = :id LIMIT 1")
    suspend fun getDownloadById(id: String): DownloadInfo?

    @Query("SELECT * FROM download_info WHERE downloadId = :downloadId LIMIT 1")
    suspend fun getDownloadBySystemId(downloadId: Long): DownloadInfo?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(downloadInfo: DownloadInfo)

    @Query("UPDATE download_info SET progress = :progress, downloadedBytes = :downloadedBytes, totalBytes = :totalBytes, status = :status WHERE downloadId = :downloadId")
    suspend fun updateProgress(downloadId: Long, progress: Float, downloadedBytes: Long, totalBytes: Long, status: String)

    @Query("UPDATE download_info SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: String, status: String)

    @Delete
    suspend fun delete(downloadInfo: DownloadInfo)
}
