package com.example.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.local.AppDatabase
import com.example.data.model.ChatMessage
import com.example.data.model.DownloadInfo
import com.example.data.repository.LocalAIRepository
import com.example.util.GgufMetadata
import com.example.util.LocalAIInference
import com.example.util.SpeechManager
import com.example.util.SystemInfo
import com.example.util.SystemMetrics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class LocalAIViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = LocalAIRepository(
        context = application,
        downloadDao = db.downloadDao(),
        chatDao = db.chatDao()
    )

    // Flow states
    val downloads: StateFlow<List<DownloadInfo>> = repository.allDownloads
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val messages: StateFlow<List<ChatMessage>> = repository.allMessages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI States
    private val _systemInfo = MutableStateFlow(SystemMetrics.getSystemInfo(application))
    val systemInfo: StateFlow<SystemInfo> = _systemInfo.asStateFlow()

    private val _activeModelId = MutableStateFlow("llama_3.2_1b")
    val activeModelId: StateFlow<String> = _activeModelId.asStateFlow()

    private val _isHybridMode = MutableStateFlow(false)
    val isHybridMode: StateFlow<Boolean> = _isHybridMode.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _themeMode = MutableStateFlow("dark") // default is dark as requested!
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _partialSpeechText = MutableStateFlow("")
    val partialSpeechText: StateFlow<String> = _partialSpeechText.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Loaded model metadata
    private val _activeMetadata = MutableStateFlow<GgufMetadata?>(null)
    val activeMetadata: StateFlow<GgufMetadata?> = _activeMetadata.asStateFlow()

    private var speechManager: SpeechManager? = null

    // API Key availability checking
    val hasApiKey: Boolean
        get() {
            val key = BuildConfig.GEMINI_API_KEY
            return key.isNotEmpty() && key != "MY_GEMINI_API_KEY"
        }

    init {
        viewModelScope.launch {
            repository.initDefaultDownloads()
            loadLoadedModelMetadata()
            
            // Periodically sync downloads & metrics
            launch {
                while (true) {
                    try {
                        repository.syncActiveDownloads()
                        updateSystemInfo()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    kotlinx.coroutines.delay(1000)
                }
            }
        }

        // Initialize speech manager
        speechManager = SpeechManager(application) {
            // Speech manager initialized successfully
        }
    }

    private fun updateSystemInfo() {
        _systemInfo.value = SystemMetrics.getSystemInfo(getApplication())
    }

    suspend fun loadLoadedModelMetadata() {
        withContext(Dispatchers.IO) {
            val activeId = _activeModelId.value
            val downloadInfo = downloads.value.find { it.id == activeId }
            if (downloadInfo != null && downloadInfo.status == "COMPLETED") {
                val metadata = repository.parseGgufMetadata(downloadInfo.localFilePath)
                _activeMetadata.value = metadata
            } else {
                _activeMetadata.value = null
            }
        }
    }

    fun selectActiveModel(id: String) {
        viewModelScope.launch {
            _activeModelId.value = id
            loadLoadedModelMetadata()
        }
    }

    fun startDownload(id: String) {
        viewModelScope.launch {
            repository.startDownload(id)
        }
    }

    fun deleteDownload(id: String) {
        viewModelScope.launch {
            repository.deleteDownload(id)
            if (_activeModelId.value == id) {
                _activeMetadata.value = null
            }
        }
    }

    fun setHybridMode(enabled: Boolean) {
        _isHybridMode.value = enabled
    }

    fun setThemeMode(mode: String) {
        _themeMode.value = mode
    }

    fun clearErrorMessage() {
        _errorMessage.value = null
    }

    fun sendMessage(content: String, speakOutput: Boolean = true) {
        if (content.isBlank() || _isGenerating.value) return

        viewModelScope.launch {
            // Stop any ongoing voice output
            speechManager?.stopSpeaking()

            val userMsg = ChatMessage(
                sender = "USER",
                content = content,
                modelUsed = getActiveModelLabel()
            )
            repository.saveMessage(userMsg)

            // Show generating indicator and placeholder AI message
            _isGenerating.value = true
            
            val activeModel = _activeModelId.value
            val hybrid = _isHybridMode.value
            
            // Check if model file is downloaded
            val isDownloaded = downloads.value.find { it.id == activeModel }?.status == "COMPLETED"
            
            if (!isDownloaded && !hybrid) {
                // Cannot chat locally if model not downloaded
                val errorMsg = ChatMessage(
                    sender = "AI",
                    content = "⚠️ El modelo seleccionado (${getActiveModelLabel()}) aún no ha sido descargado. Por favor, abre el centro de descargas pulsando el botón de la barra superior y descárgalo, o activa el 'Modo Híbrido Nube/Local' para utilizar la API remota.",
                    modelUsed = getActiveModelLabel()
                )
                repository.saveMessage(errorMsg)
                _isGenerating.value = false
                return@launch
            }

            var aiMsg = ChatMessage(
                sender = "AI",
                content = "...",
                modelUsed = if (hybrid) "Híbrido (Nube)" else getActiveModelLabel()
            )
            repository.saveMessage(aiMsg)

            // Let's retrieve the placeholder message ID to update it
            val allMsgs = repository.allMessages.stateIn(viewModelScope).value
            val savedPlaceholder = allMsgs.lastOrNull { it.sender == "AI" && it.content == "..." }
            val placeholderId = savedPlaceholder?.id ?: 0L

            var lastEmission = ""
            LocalAIInference.generateLocalResponse(content, activeModel, hybrid, hasApiKey).collectLatest { partialText ->
                lastEmission = partialText
                if (placeholderId != 0L) {
                    repository.saveMessage(
                        ChatMessage(
                            id = placeholderId,
                            sender = "AI",
                            content = partialText,
                            modelUsed = if (hybrid) "Híbrido (Nube)" else getActiveModelLabel()
                        )
                    )
                }
            }

            _isGenerating.value = false

            // Voice synthesis
            if (speakOutput && lastEmission.isNotEmpty()) {
                // Strip markdown backticks/blocks for cleaner TTS
                val cleanText = lastEmission
                    .replace(Regex("```[a-zA-Z]*\\n"), "")
                    .replace("```", "")
                    .replace(Regex("[*#_`]"), "")
                speechManager?.speak(cleanText)
            }
        }
    }

    private fun getActiveModelLabel(): String {
        return when (_activeModelId.value) {
            "llama_3.2_1b" -> "Llama 3.2 1B"
            "qwen_2.5_0.5b" -> "Qwen 2.5 0.5B"
            else -> "Modelo Local"
        }
    }

    fun clearChat() {
        viewModelScope.launch {
            speechManager?.stopSpeaking()
            repository.clearChatHistory()
        }
    }

    // Voice Input Controls
    fun startListening() {
        _partialSpeechText.value = ""
        _isListening.value = true
        speechManager?.startListening(
            onResult = { result ->
                _isListening.value = false
                _partialSpeechText.value = ""
                sendMessage(result)
            },
            onError = { error ->
                _isListening.value = false
                _partialSpeechText.value = ""
                _errorMessage.value = error
            },
            onPartialResult = { partial ->
                _partialSpeechText.value = partial
            }
        )
    }

    fun stopListening() {
        _isListening.value = false
        speechManager?.stopListening()
    }

    fun speakText(text: String) {
        val cleanText = text
            .replace(Regex("```[a-zA-Z]*\\n"), "")
            .replace("```", "")
            .replace(Regex("[*#_`]"), "")
        speechManager?.speak(cleanText)
    }

    fun stopSpeaking() {
        speechManager?.stopSpeaking()
    }

    override fun onCleared() {
        super.onCleared()
        speechManager?.destroy()
    }
}
