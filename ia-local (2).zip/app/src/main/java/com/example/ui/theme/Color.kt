package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFF80DEEA)
val PurpleGrey80 = Color(0xFFB0BEC5)
val Pink80 = Color(0xFFFFAB40)

val Purple40 = Color(0xFF00ACC1)
val PurpleGrey40 = Color(0xFF546E7A)
val Pink40 = Color(0xFFFB8C00)

// High-fidelity custom OS-inspired colors with Geometric Balance theme
val SlateDark = Color(0xFF1C1B1F)       // Dark charcoal background
val SlateMedium = Color(0xFF2B2930)     // Dark slate card surface color
val SlateLight = Color(0xFF49454F)      // Muted charcoal border
val NeonCyan = Color(0xFFD0BCFF)        // Soft violet primary accent
val NeonIndigo = Color(0xFF9A82DB)      // Muted violet secondary accent
val NeonGreen = Color(0xFFBACF83)       // Sage green for success state
val NeonOrange = Color(0xFFF2B8B5)      // Coral rose for active/listening states
val TerminalText = Color(0xFFE6E1E5)    // Off-white readable text
val TerminalGrid = Color(0xFF49454F)    // Clean geometric grid outline


