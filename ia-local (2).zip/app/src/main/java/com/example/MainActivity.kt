package com.example

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.ChatMessage
import com.example.data.model.DownloadInfo
import com.example.ui.LocalAIViewModel
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonIndigo
import com.example.ui.theme.NeonOrange
import com.example.ui.theme.SlateDark
import com.example.ui.theme.SlateLight
import com.example.ui.theme.SlateMedium
import com.example.ui.theme.TerminalText
import com.example.util.GgufMetadata
import com.example.util.SystemInfo
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: LocalAIViewModel = viewModel()
            val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
            
            val isDarkTheme = when (themeMode) {
                "light" -> false
                "dark" -> true
                else -> isSystemInDarkTheme()
            }

            MyApplicationTheme(darkTheme = isDarkTheme) {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.background)
                            .padding(innerPadding)
                    ) {
                        DashboardScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(viewModel: LocalAIViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    
    // ViewModel states
    val downloads by viewModel.downloads.collectAsStateWithLifecycle()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val systemInfo by viewModel.systemInfo.collectAsStateWithLifecycle()
    val activeModelId by viewModel.activeModelId.collectAsStateWithLifecycle()
    val isHybridMode by viewModel.isHybridMode.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
    val isListening by viewModel.isListening.collectAsStateWithLifecycle()
    val partialSpeechText by viewModel.partialSpeechText.collectAsStateWithLifecycle()
    val errorMessage by viewModel.errorMessage.collectAsStateWithLifecycle()
    val activeMetadata by viewModel.activeMetadata.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()

    // Sheet states
    var showDownloadSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // Permission handling
    val speechPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startListening()
        } else {
            Toast.makeText(context, "Permiso de micrófono denegado", Toast.LENGTH_SHORT).show()
        }
    }

    // Error handler
    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            Toast.makeText(context, "Error: $it", Toast.LENGTH_LONG).show()
            viewModel.clearErrorMessage()
        }
    }

    // Auto-scroll chat state
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size, isGenerating) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("dashboard_screen")
    ) {
        // --- Custom OS System Header ---
        SystemHeader(
            systemInfo = systemInfo,
            activeModelLabel = if (activeModelId == "llama_3.2_1b") "Llama 3.2" else "Qwen 2.5",
            isHybridMode = isHybridMode,
            onManageModels = { showDownloadSheet = true },
            themeMode = themeMode,
            onThemeChange = { viewModel.setThemeMode(it) }
        )

        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), thickness = 1.dp)

        // --- Hardware Monitor Overview ---
        HardwareOverview(systemInfo = systemInfo)

        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), thickness = 1.dp)

        // --- Active Model Details Tag ---
        ActiveModelBar(
            activeModelId = activeModelId,
            downloads = downloads,
            activeMetadata = activeMetadata,
            isHybridMode = isHybridMode,
            onModelSelect = { viewModel.selectActiveModel(it) },
            onManage = { showDownloadSheet = true }
        )

        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), thickness = 1.dp)

        // --- Chat Terminal Panel ---
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (messages.isEmpty()) {
                WelcomeTerminal(
                    activeModelId = activeModelId,
                    isHybridMode = isHybridMode,
                    downloads = downloads,
                    onChipClick = { viewModel.sendMessage(it) },
                    onManage = { showDownloadSheet = true }
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    contentPadding = PaddingValues(vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(messages) { message ->
                        ChatBubbleItem(
                            message = message,
                            onSpeakClick = { viewModel.speakText(message.content) },
                            onStopSpeakClick = { viewModel.stopSpeaking() }
                        )
                    }
                    if (isGenerating) {
                        item {
                            GeneratingIndicatorItem()
                        }
                    }
                }
            }

            // Microphone overlay when listening
            if (isListening) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.75f))
                        .clickable(enabled = false) {},
                    contentAlignment = Alignment.Center
                ) {
                    VoiceListeningCard(
                        partialSpeechText = partialSpeechText,
                        onCancel = { viewModel.stopListening() }
                    )
                }
            }
        }

        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), thickness = 1.dp)

        // --- Control Entry / Command input Bar ---
        CommandBar(
            isGenerating = isGenerating,
            onSendMessage = { viewModel.sendMessage(it) },
            onClearChat = { viewModel.clearChat() },
            isListening = isListening,
            onMicClick = {
                val permission = Manifest.permission.RECORD_AUDIO
                if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
                    viewModel.startListening()
                } else {
                    speechPermissionLauncher.launch(permission)
                }
            }
        )
    }

    // --- Model Download Center Bottom Sheet ---
    if (showDownloadSheet) {
        ModalBottomSheet(
            onDismissRequest = { showDownloadSheet = false },
            sheetState = sheetState,
            containerColor = MaterialTheme.colorScheme.background,
            scrimColor = Color.Black.copy(alpha = 0.6f)
        ) {
            DownloadSheetContent(
                downloads = downloads,
                onDownloadStart = { viewModel.startDownload(it) },
                onDownloadDelete = { viewModel.deleteDownload(it) },
                onDismiss = {
                    coroutineScope.launch { sheetState.hide() }.invokeOnCompletion {
                        if (!sheetState.isVisible) showDownloadSheet = false
                    }
                }
            )
        }
    }
}

// ================= COMPOSABLE COMPONENTS =================

@Composable
fun SystemHeader(
    systemInfo: SystemInfo,
    activeModelLabel: String,
    isHybridMode: Boolean,
    onManageModels: () -> Unit,
    themeMode: String,
    onThemeChange: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (isHybridMode) NeonIndigo else NeonGreen)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "CORE_OS: IA LOCAL",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Text(
                text = "Modo: ${if (isHybridMode) "Híbrido Nube" else "Local Offline ($activeModelLabel)"}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                fontFamily = FontFamily.Monospace
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Theme Mode Toggle button
            IconButton(
                onClick = {
                    val nextMode = when (themeMode) {
                        "dark" -> "light"
                        "light" -> "system"
                        else -> "dark"
                    }
                    onThemeChange(nextMode)
                }
            ) {
                Icon(
                    imageVector = when (themeMode) {
                        "dark" -> Icons.Default.DarkMode
                        "light" -> Icons.Default.LightMode
                        else -> Icons.Default.SettingsSuggest
                    },
                    contentDescription = "Cambiar modo de tema",
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            // Model Manager Button
            Button(
                onClick = onManageModels,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.primary
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.testTag("manage_models_button")
            ) {
                Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Modelos", style = MaterialTheme.typography.labelMedium, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
fun HardwareOverview(systemInfo: SystemInfo) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header: System Status
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(NeonCyan),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.DeveloperBoard,
                        contentDescription = null,
                        tint = Color(0xFF381E72), // Dark violet contrast text
                        modifier = Modifier.size(24.dp)
                    )
                }
                Column {
                    Text(
                        text = "Estado del Sistema",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Listo para configuración y prompts",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), thickness = 1.dp)
            Spacer(modifier = Modifier.height(16.dp))

            // Stats row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // CPU Card
                HardwareStat(
                    label = "CPU CORES",
                    value = "${systemInfo.cpuCores}",
                    percent = 1f, // Static indicator
                    color = NeonCyan,
                    icon = Icons.Default.DeveloperBoard
                )
                
                // RAM Card
                HardwareStat(
                    label = "MEMORIA RAM",
                    value = "${String.format("%.1f", systemInfo.usedRamGb)}/${String.format("%.1f", systemInfo.totalRamGb)} GB",
                    percent = systemInfo.ramUsagePercent / 100f,
                    color = NeonIndigo,
                    icon = Icons.Default.Memory
                )

                // Storage Card
                HardwareStat(
                    label = "DISCO LOCAL",
                    value = "${String.format("%.1f", systemInfo.freeStorageGb)} GB",
                    percent = (100f - systemInfo.storageUsagePercent) / 100f, // Free storage indicator
                    color = NeonOrange,
                    icon = Icons.Default.Storage
                )
            }
        }
    }
}

@Composable
fun HardwareStat(
    label: String,
    value: String,
    percent: Float,
    color: Color,
    icon: ImageVector
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.width(115.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(
                text = label,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
            Text(
                text = value,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
            Spacer(modifier = Modifier.height(3.dp))
            LinearProgressIndicator(
                progress = { percent.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(RoundedCornerShape(1.dp)),
                color = color,
                trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f)
            )
        }
    }
}

@Composable
fun ActiveModelBar(
    activeModelId: String,
    downloads: List<DownloadInfo>,
    activeMetadata: GgufMetadata?,
    isHybridMode: Boolean,
    onModelSelect: (String) -> Unit,
    onManage: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "MODELO DE LLM ACTIVO",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 4.dp)
            ) {
                // Radio selectors
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onModelSelect("llama_3.2_1b") }
                ) {
                    RadioButton(
                        selected = activeModelId == "llama_3.2_1b",
                        onClick = { onModelSelect("llama_3.2_1b") },
                        colors = RadioButtonDefaults.colors(selectedColor = NeonCyan),
                        modifier = Modifier.size(30.dp)
                    )
                    Text(
                        "Llama 3.2 1B",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = if (activeModelId == "llama_3.2_1b") FontWeight.Bold else FontWeight.Normal,
                        color = if (activeModelId == "llama_3.2_1b") NeonCyan else MaterialTheme.colorScheme.onBackground
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onModelSelect("qwen_2.5_0.5b") }
                ) {
                    RadioButton(
                        selected = activeModelId == "qwen_2.5_0.5b",
                        onClick = { onModelSelect("qwen_2.5_0.5b") },
                        colors = RadioButtonDefaults.colors(selectedColor = NeonCyan),
                        modifier = Modifier.size(30.dp)
                    )
                    Text(
                        "Qwen 2.5 0.5B",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = if (activeModelId == "qwen_2.5_0.5b") FontWeight.Bold else FontWeight.Normal,
                        color = if (activeModelId == "qwen_2.5_0.5b") NeonCyan else MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }

        val activeModelInfo = downloads.find { it.id == activeModelId }
        val isDownloaded = activeModelInfo?.status == "COMPLETED"

        Column(
            horizontalAlignment = Alignment.End,
            modifier = Modifier.padding(start = 8.dp)
        ) {
            if (isHybridMode) {
                Box(
                    modifier = Modifier
                        .background(NeonIndigo.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .border(1.dp, NeonIndigo, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        "MODO NUBE ACTIVO",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = NeonIndigo,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else if (isDownloaded) {
                Box(
                    modifier = Modifier
                        .background(NeonGreen.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .border(1.dp, NeonGreen, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .clickable {
                            // Expand metadata popup if clicked
                        }
                ) {
                    Text(
                        "LISTO LOCAL (GGUF)",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = NeonGreen,
                        fontWeight = FontWeight.Bold
                    )
                }
                activeMetadata?.let {
                    Text(
                        "Tensors: ${it.tensorCount} | v${it.version}",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            } else {
                Button(
                    onClick = onManage,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonOrange),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.height(24.dp)
                ) {
                    Text(
                        "REQUERIDO DESCARGAR",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun WelcomeTerminal(
    activeModelId: String,
    isHybridMode: Boolean,
    downloads: List<DownloadInfo>,
    onChipClick: (String) -> Unit,
    onManage: () -> Unit
) {
    val modelLabel = if (activeModelId == "llama_3.2_1b") "Llama 3.2 1B Instruct" else "Qwen 2.5 0.5B"
    val isDownloaded = downloads.find { it.id == activeModelId }?.status == "COMPLETED"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Futuristic Terminal Icon
        Box(
            modifier = Modifier
                .size(64.dp)
                .drawBehind {
                    drawCircle(
                        color = NeonCyan.copy(alpha = 0.15f),
                        radius = size.width / 2
                    )
                    drawCircle(
                        color = NeonCyan,
                        radius = size.width / 2,
                        style = Stroke(2.dp.toPx())
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Terminal,
                contentDescription = null,
                tint = NeonCyan,
                modifier = Modifier.size(32.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(
            "SISTEMA DE ASISTENCIA IA LOCAL",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.Monospace,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            "ESTADO DEL CORE OS: ONLINE Y ENCRIPTADO",
            style = MaterialTheme.typography.bodySmall,
            fontFamily = FontFamily.Monospace,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // System Diagnostic Panel
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(SlateMedium, RoundedCornerShape(24.dp))
                .border(1.dp, SlateLight, RoundedCornerShape(24.dp))
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    buildAnnotatedString {
                        withStyle(style = SpanStyle(color = NeonCyan, fontWeight = FontWeight.Bold)) {
                            append("[OS] ")
                        }
                        append("Plataforma: Android Local AI Engine")
                    },
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TerminalText
                )
                Text(
                    buildAnnotatedString {
                        withStyle(style = SpanStyle(color = NeonCyan, fontWeight = FontWeight.Bold)) {
                            append("[MODELO] ")
                        }
                        append("Núcleo Seleccionado: $modelLabel")
                    },
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TerminalText
                )
                Text(
                    buildAnnotatedString {
                        withStyle(style = SpanStyle(color = NeonCyan, fontWeight = FontWeight.Bold)) {
                            append("[ESTADO] ")
                        }
                        if (isHybridMode) {
                            append("Modo Híbrido Nube (Conexión Activa)")
                        } else if (isDownloaded) {
                            append("Listo Offline (Directo en Hardware)")
                        } else {
                            append("Falta Descargar Archivo GGUF")
                        }
                    },
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = if (isHybridMode) NeonIndigo else if (isDownloaded) NeonGreen else NeonOrange
                )
                Text(
                    buildAnnotatedString {
                        withStyle(style = SpanStyle(color = NeonCyan, fontWeight = FontWeight.Bold)) {
                            append("[SOPORTE] ")
                        }
                        append("Voz en Español España/Latino (Offline TTS)")
                    },
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TerminalText
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Action Prompts Label
        Text(
            "PROMPTS DE PRUEBA RÁPIDOS",
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
            modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Quick Command Chips
        val commands = listOf(
            "¡Hola, IA Local!",
            "¿Quién eres?",
            "Dime un chiste",
            "Código Kotlin",
            "Háblame de Qwen 2.5"
        )

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for (cmd in commands) {
                SuggestionChip(
                    onClick = { onChipClick(cmd) },
                    label = { Text(cmd, fontFamily = FontFamily.Monospace, fontSize = 11.sp) },
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(6.dp)
                )
            }
        }

        if (!isDownloaded && !isHybridMode) {
            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = onManage,
                colors = ButtonDefaults.buttonColors(containerColor = NeonOrange),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.CloudDownload, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Descargar Modelo IA para funcionar", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color.Black)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FlowRow(
    modifier: Modifier = Modifier,
    horizontalArrangement: Arrangement.Horizontal = Arrangement.Start,
    verticalArrangement: Arrangement.Vertical = Arrangement.Top,
    content: @Composable () -> Unit
) {
    androidx.compose.foundation.layout.FlowRow(
        modifier = modifier,
        horizontalArrangement = horizontalArrangement,
        verticalArrangement = verticalArrangement
    ) {
        content()
    }
}

@Composable
fun ChatBubbleItem(
    message: ChatMessage,
    onSpeakClick: () -> Unit,
    onStopSpeakClick: () -> Unit
) {
    val isUser = message.sender == "USER"
    var speaking by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            // AI Icon Avatar
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(NeonCyan.copy(alpha = 0.15f))
                    .border(1.dp, NeonCyan, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.SmartToy,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Column(
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
            modifier = Modifier.weight(1f, fill = false)
        ) {
            // Sender tag and info
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = if (isUser) "TÚ" else message.modelUsed.uppercase(),
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = if (isUser) NeonCyan else NeonIndigo
                )
                Text(
                    text = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(message.timestamp),
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Text Bubble Card
            Box(
                modifier = Modifier
                    .clip(
                        RoundedCornerShape(
                            topStart = if (isUser) 12.dp else 2.dp,
                            topEnd = if (isUser) 2.dp else 12.dp,
                            bottomStart = 12.dp,
                            bottomEnd = 12.dp
                        )
                    )
                    .background(if (isUser) SlateLight else SlateMedium)
                    .border(
                        width = 1.dp,
                        color = if (isUser) NeonCyan.copy(alpha = 0.3f) else SlateLight,
                        shape = RoundedCornerShape(
                            topStart = if (isUser) 12.dp else 2.dp,
                            topEnd = if (isUser) 2.dp else 12.dp,
                            bottomStart = 12.dp,
                            bottomEnd = 12.dp
                        )
                    )
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = message.content,
                        style = MaterialTheme.typography.bodyMedium,
                        fontFamily = FontFamily.Monospace,
                        color = TerminalText,
                        lineHeight = 18.sp
                    )

                    // Audio Speak Action for AI responses
                    if (!isUser) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            horizontalArrangement = Arrangement.End,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            IconButton(
                                onClick = {
                                    if (speaking) {
                                        onStopSpeakClick()
                                        speaking = false
                                    } else {
                                        onSpeakClick()
                                        speaking = true
                                    }
                                },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = if (speaking) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                    contentDescription = "Escuchar respuesta",
                                    tint = NeonCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        if (isUser) {
            Spacer(modifier = Modifier.width(8.dp))
            // User Icon Avatar
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(SlateMedium)
                    .border(1.dp, NeonCyan.copy(alpha = 0.5f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun GeneratingIndicatorItem() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(NeonCyan.copy(alpha = 0.15f))
                .border(1.dp, NeonCyan, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.SmartToy,
                contentDescription = null,
                tint = NeonCyan,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(2.dp, 12.dp, 12.dp, 12.dp))
                .background(SlateMedium)
                .padding(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "PROCESANDO_NUCLEO_LOCAL",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = NeonCyan,
                    fontWeight = FontWeight.Bold
                )
                // Small blinking cursor
                val infiniteTransition = rememberInfiniteTransition(label = "cursor")
                val alpha by infiniteTransition.animateFloat(
                    initialValue = 0f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(500, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "alpha"
                )
                Box(
                    modifier = Modifier
                        .size(6.dp, 12.dp)
                        .background(NeonCyan.copy(alpha = alpha))
                )
            }
        }
    }
}

@Composable
fun CommandBar(
    isGenerating: Boolean,
    onSendMessage: (String) -> Unit,
    onClearChat: () -> Unit,
    isListening: Boolean,
    onMicClick: () -> Unit
) {
    var textInput by remember { mutableStateOf("") }
    val keyboardController = LocalSoftwareKeyboardController.current

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(SlateMedium)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Clear chat button
        IconButton(
            onClick = onClearChat,
            modifier = Modifier
                .size(40.dp)
                .background(SlateLight, RoundedCornerShape(12.dp))
                .border(1.dp, SlateLight, RoundedCornerShape(12.dp))
        ) {
            Icon(Icons.Default.Delete, contentDescription = "Limpiar Consola", tint = Color.Red.copy(alpha = 0.8f))
        }

        // Voice record mic button
        IconButton(
            onClick = onMicClick,
            modifier = Modifier
                .size(40.dp)
                .background(if (isListening) NeonOrange else SlateLight, RoundedCornerShape(12.dp))
                .border(1.dp, if (isListening) NeonOrange else SlateLight, RoundedCornerShape(12.dp))
        ) {
            Icon(
                imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                contentDescription = "Grabar voz en español",
                tint = if (isListening) Color.Black else NeonCyan
            )
        }

        // Input Text CLI Terminal field
        TextField(
            value = textInput,
            onValueChange = { textInput = it },
            placeholder = { Text("> Escribe un prompt local...", fontFamily = FontFamily.Monospace, fontSize = 12.sp) },
            textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = TerminalText),
            modifier = Modifier
                .weight(1f)
                .testTag("chat_input_field"),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = SlateDark,
                unfocusedContainerColor = SlateDark,
                disabledContainerColor = SlateDark,
                focusedIndicatorColor = NeonCyan,
                unfocusedIndicatorColor = Color.Transparent,
                focusedTextColor = TerminalText,
                unfocusedTextColor = TerminalText,
                focusedPlaceholderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                unfocusedPlaceholderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
            ),
            shape = RoundedCornerShape(12.dp),
            singleLine = true,
            trailingIcon = {
                if (textInput.isNotEmpty()) {
                    IconButton(onClick = { textInput = "" }) {
                        Icon(Icons.Default.Close, contentDescription = null, tint = TerminalText.copy(alpha = 0.5f))
                    }
                }
            }
        )

        // Send Button
        IconButton(
            onClick = {
                if (textInput.isNotBlank()) {
                    onSendMessage(textInput)
                    textInput = ""
                    keyboardController?.hide()
                }
            },
            enabled = textInput.isNotBlank() && !isGenerating,
            modifier = Modifier
                .size(40.dp)
                .background(
                    if (textInput.isNotBlank() && !isGenerating) NeonCyan else SlateLight,
                    RoundedCornerShape(12.dp)
                )
        ) {
            Icon(
                imageVector = Icons.Default.Send,
                contentDescription = "Enviar prompt",
                tint = if (textInput.isNotBlank() && !isGenerating) Color.Black else TerminalText.copy(alpha = 0.3f)
            )
        }
    }
}

@Composable
fun VoiceListeningCard(
    partialSpeechText: String,
    onCancel: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SlateMedium),
        border = BorderStroke(2.dp, NeonOrange),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier
            .fillMaxWidth(0.85f)
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                "ESCUCHANDO VOZ EN ESPAÑOL...",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = NeonOrange,
                fontSize = 12.sp
            )

            // Dynamic microphone animated wave
            val infiniteTransition = rememberInfiniteTransition(label = "pulse")
            val pulseRadius by infiniteTransition.animateFloat(
                initialValue = 40f,
                targetValue = 64f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1000, easing = LinearOutSlowInEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "pulseRadius"
            )
            val pulseAlpha by infiniteTransition.animateFloat(
                initialValue = 0.6f,
                targetValue = 0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1000, easing = LinearOutSlowInEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "pulseAlpha"
            )

            Box(
                modifier = Modifier
                    .size(96.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(pulseRadius.dp)
                        .clip(CircleShape)
                        .background(NeonOrange.copy(alpha = pulseAlpha))
                )
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(NeonOrange),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Text(
                text = if (partialSpeechText.isEmpty()) "Hable ahora..." else "\"$partialSpeechText\"",
                fontFamily = FontFamily.Monospace,
                color = TerminalText,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = onCancel,
                colors = ButtonDefaults.buttonColors(containerColor = SlateLight),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Cancelar", fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
fun DownloadSheetContent(
    downloads: List<DownloadInfo>,
    onDownloadStart: (String) -> Unit,
    onDownloadDelete: (String) -> Unit,
    onDismiss: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .navigationBarsPadding(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "CENTRO DE DESCARGA LOCAL",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.primary
            )
            IconButton(onClick = onDismiss) {
                Icon(Icons.Default.Close, contentDescription = "Cerrar")
            }
        }

        Text(
            "Descarga los modelos directo a la memoria local de la app. Los archivos se guardarán localmente para funcionar 100% sin internet.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
            fontFamily = FontFamily.Monospace
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(downloads) { model ->
                DownloadModelItem(
                    model = model,
                    onDownload = { onDownloadStart(model.id) },
                    onDelete = { onDownloadDelete(model.id) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun DownloadModelItem(
    model: DownloadInfo,
    onDownload: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SlateMedium),
        border = BorderStroke(1.dp, SlateLight),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = model.name,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = TerminalText
                    )
                    Text(
                        text = "Tamaño: ${model.sizeLabel}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                // Delete button for completed files
                if (model.status == "COMPLETED") {
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(32.dp)
                            .background(Color.Red.copy(alpha = 0.1f), CircleShape)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = Color.Red, modifier = Modifier.size(16.dp))
                    }
                }
            }

            // Progress bar or direct Action Button
            when (model.status) {
                "NOT_DOWNLOADED", "FAILED" -> {
                    Button(
                        onClick = onDownload,
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (model.status == "FAILED") "Reintentar Descarga" else "Iniciar Descarga",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black,
                            fontSize = 12.sp
                        )
                    }
                }
                "DOWNLOADING" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Descargando... ${String.format("%.1f", model.progress * 100)}%",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = NeonOrange,
                                fontWeight = FontWeight.Bold
                            )
                            if (model.totalBytes > 0) {
                                Text(
                                    text = "${String.format("%.1f", model.downloadedBytes.toFloat() / (1024f * 1024f))} MB / ${String.format("%.1f", model.totalBytes.toFloat() / (1024f * 1024f))} MB",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalText.copy(alpha = 0.5f)
                                )
                            }
                        }
                        LinearProgressIndicator(
                            progress = { model.progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = NeonOrange,
                            trackColor = SlateLight
                        )
                    }
                }
                "COMPLETED" -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(NeonGreen.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                            .border(1.dp, NeonGreen.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Descargado y guardado en local",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = NeonGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                "PAUSED" -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(NeonOrange.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                            .border(1.dp, NeonOrange.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Pause, contentDescription = null, tint = NeonOrange, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Descarga en pausa en segundo plano...",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = NeonOrange,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
